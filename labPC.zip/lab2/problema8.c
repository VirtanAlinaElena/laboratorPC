#include <stdio.h>

int main()
{
	int A, B, C;
	scanf("%d%d%d", &A, &B, &C);
	if (A<B && B<C) printf("%d %d %d\n", A, B, C);
	if (A<C && C<B) printf("%d %d %d\n", A, C, B);
	if (B<A && A<C) printf("%d %d %d\n", B, A, C);
	if (B<C && C<A) printf("%d %d %d\n", B, C, A);
	if (C<A && A<B) printf("%d %d %d\n", C, A, B);
	if (C<B && B<A) printf("%d %d %d\n", C, B, A);
}