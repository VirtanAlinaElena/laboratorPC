#include <stdio.h>

int main()
{
	int H,M,S;
	scanf("%d%d%d", &H, &M, &S);
	printf("%02d:%02d:%02d\n", H, M, S);
}