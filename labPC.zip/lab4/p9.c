#include <stdio.h>

int main()
{
	int n,i,a[101],k,p,OK;
	scanf("%d", &n);
	for (i=0; i<n; i++)
		scanf("%d", &a[i]);
	OK=1;
	for (i=1; i<n; i++)
		if (a[i]!=a[0]) OK=0;
	if (OK==1) printf("constant\n"); 
	k=0;
	for (i=1; i<n; i++)
		if ( a[i-1]<a[i] ) k++;
	if ( k == (n-1) ) printf ("crescator\n");
	p=0;
	for (i=1; i<n; i++)
		if ( a[i-1]>a[i] ) p++;
	if (p == (n-1)) printf ("descrescator\n");
	if (OK==0 && p!=(n-1) && k!=(n-1)) printf("neordonat\n");
	return 0;
}
