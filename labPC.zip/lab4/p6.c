#include <stdio.h>

int main()
{
	int i,j,v[101][101],n;
	scanf("%d", &n);
	for (i=0; i<n; i++)
		for (j=0; j<n; j++)
		scanf("%d", &v[i][j]);
	for (j=0; j<n; j++)
		for (i=0; i<n; i++)
			if (i+j>=n)
				printf ("%d ", v[i][j]);
}
  
