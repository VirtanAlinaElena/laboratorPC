#include <stdio.h>

int main()
{
	int n,m,val,beg,end,i,k;
	scanf("%d %d", &n, &m);
	int v[n];
	for (i = 0; i < n; i++)
		v[i] = 0;
	for (i = 1; i <= m; i++)
	{
		scanf("%d %d %d", &beg, &end, &val);
		for (k = beg; k <=end; k++)
			v[k] += val;
	}
	for (k=0; k<n; k++)
		printf("%d ", v[k]);
       printf("\n");
       return 0;	

}
