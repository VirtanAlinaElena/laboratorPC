#include <stdio.h>

int main ()
{
	int n, m, i, j, Min, Max, v[102][102];
	scanf("%d%d", &n, &m);
	Min=99999999;
	for (i=0; i<=n-1; i++)
	{
		Max=-99999999;
		for (j=0; j<=m-1; j++)
		{
			scanf("%d", &v[i][j]);
			if (v[i][j]>Max) Max=v[i][j];
		}
		if (Max<Min) Min=Max;
	}
	printf ("%d\n", Min);

	return 0;
}