#include <stdio.h>

int main()
{
	int n,i,v[101],lmax=0,end,start,START,END;
	scanf ("%d", &n);
	for (i=0; i<n; i++)
		scanf("%d", &v[i]);
	start=end=0;
	for (i=1; i<n; i++)
		if (v[i-1]<v[i])
			end=i;
		else 
			{
				if (end-start+1 > lmax) {
					lmax = end-start+1;
					START=start;
					END=end;
				}

				start=end=i;
			}
	if (end-start+1 > lmax) {
					lmax = end-start+1;
					START=start;
					END=end;
				}
	for (i=START; i<=END; i++)
		printf ("%d ", v[i]);
}
