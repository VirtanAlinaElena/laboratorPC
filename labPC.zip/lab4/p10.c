#include <stdio.h>

int main()
{
	int n,m,s[1001],i,j;
	float v[101];
	int beg, end;
	
	scanf("%d", &n);
	for (i=0; i<n; i++) 
		scanf("%f", &v[i]);
	
	scanf ("%d", &m);
	for (i=0; i<m; i++) 
		scanf ("%d", &s[i]);
	int ok = 1; // pp ca sunt sortate crescator
	for (i=1; i<m && ok == 1; i++)
		if (s[i-1] > s[i]) 
			ok = 0;
	if (ok==0) printf("Error\n");
	else
	{
		int k=0;
		for (i=1; i<m; i++)
		{	
			k=0;
			beg = s[i-1];
			end = s[i];
			for (j=0; j<n; j++)
				if ( v[j] - beg > 0 && end - v[j] > 0 )
					k++;
			printf ("%d ", k);
		}
		printf("\n");
	}
	return 0;
}
