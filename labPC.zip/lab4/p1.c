#include <stdio.h>

int main()
{
	int i,n,k1,k2,v[102];
	k1=k2=0;
	scanf("%d",&n);
	for (i=0; i<=n-1; i++)
	{
		scanf ("%d", &v[i]);
		if (v[i]>=0) k1++;
			else k2++;
	}
	printf("%d %d\n", k2, k1);
	return 0;
}