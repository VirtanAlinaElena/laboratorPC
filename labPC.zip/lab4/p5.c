#include <stdio.h>

int main()
{
	int n1,n2,i,j,k,a[101],b[101],c[202],t;
	scanf("%d", &n1);
	for (i=0; i<n1-1; i++)
		scanf ("%d", &a[i]);
	scanf("%d", &n2);
	for (i=0; i<n2-1; i++)
		scanf("%d", &b[i]);
	i=j=k=0;
	i=j=k=0;
	while (i<n1 && j<n2)
	        if (a[i]<b[j])
	            {
	                c[k]=a[i];
	                i++;
	                k++;
	            }
	            else
	                {
	                    c[k]=b[j];
	                    j++;
	                    k++;
	                }
	if (i<n1)
	    for (t=i; t<n1; t++)
	            {
	                c[k]=a[t];
	                k++;
	            }
	            else
	                for (t=j; t<n2; t++)
	                    {
	                        c[k]=b[t];
	                        k++;
	                    }
	for (i=0; i<n1+n2; i++)	
       printf ("%d ", c[i]);
   	return 0;
	     

}
