#include <stdio.h>
#include <math.h>

int main()
{
	double x, rez=0;
	int n, i;
	int v[i];
	scanf("%lf %d", &x, &n);
	for (i=0; i<=n; i++)
	{	scanf("%d", &v[i]);
		rez += v[i] * pow(x, n-i);
	}
	printf("%.2f\n", rez);	
	return 0;
}
