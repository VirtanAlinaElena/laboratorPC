#include <stdio.h>

int main()
{
	double x, rez=0;
	int n;
	int v[50];
	int i;
	scanf("%lf %d", &x, &n);
	for (i=0; i<=n; i++)
	{
		scanf("%d", &v[i]);
		if (i==0) rez = v[i];
		else
			rez = rez * x + v[i];
	}
	printf("%.2f\n", rez);
	return 0;
}
