#include <stdio.h>

int main()
{
	int m,n,p,q,a[101][101],b[101][101],c[101][101],i,j,k,r;
	scanf("%d%d", &m, &n);
	for (i=0; i<m; i++)
		for (j=0; j<n; j++)
			scanf("%d", &a[i][j]);
	scanf ("%d%d", &p, &q);
	for (i=0; i<p; i++)
		for (j=0; j<q; j++)
			scanf("%d", &b[i][j]);
	if (n!=p) printf ("imposibil\n");
		else
		{
			for (i=0; i<m; i++)
				for (j=0; j<n; j++)
					for (k=0; k<q; k++)
							c[i][k]=a[i][j]*b[j][k];
			printf("%d %d\n", m, q);
			for (i=0; i<m; i++)
			{
				for (j=0; j<q; j++)
					printf ("%d ", c[i][j]);
				printf ("\n");
			}

		}
}