#include <stdio.h>
int main()
{
  	int n,i,j,S,v[101];
  	scanf ("%d", &n);
	for (i=0; i<n; i++)
		scanf("%d", &v[i]);
	int smax=0;
	int end=0;
	int beg=0;
	for (i=0; i<n; i++)
	{	S=0;
		for (j=i; j<n; j++)
		{
			S += v[j];
			if (S > smax)
			{
				smax=S;
				beg=i;
				end=j;
			}
		}
	}
	for (i=beg; i<=end; i++)
		printf("%d ", v[i]);
	printf("\n");
	return 0;
}
