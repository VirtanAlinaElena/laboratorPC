#include <stdio.h>

int main()
{
	int x;
	double y;
	scanf("%d", &x);
	scanf ("%lf", &y);
	if ( y-x > 0)
		printf("%.2f", y-x);
	return 0;
}
