#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void codificare (char text[], char text_codificat[], int* nr)
{
	int i;
	int nr_caract=0;
	for (i = 0; i < strlen(text); i++) {
		switch ( text[i] ) {
			case 'a':
			{
				if (i!=0)
					if (text_codificat[nr_caract-1] == '2') 
						text_codificat[nr_caract++] = '#';
				text_codificat[nr_caract++] = '2';
				break;
			}
			case 'A':
			{
				text_codificat[nr_caract++] = '1';
				text_codificat[nr_caract++] = '2';
				break;
			}

			case 'b':
			{
				if (i!=0)
					if (text_codificat[nr_caract-1] == '2') 
						text_codificat[nr_caract++] = '#';
				text_codificat[nr_caract++] = '2';
				text_codificat[nr_caract++] = '2';
				break;
			}
			case 'B':
			{
				text_codificat[nr_caract++] = '1';
				text_codificat[nr_caract++] = '2';
				text_codificat[nr_caract++] = '2';
				break;
			}
			case 'c':
			{
				if (i!=0)
					if (text_codificat[nr_caract-1] == '2') 
						text_codificat[nr_caract++] = '#';
				text_codificat[nr_caract++] = '2';
				text_codificat[nr_caract++] = '2';
				text_codificat[nr_caract++] = '2';
				break;
			}
			case 'C':
			{
				text_codificat[nr_caract++] = '1';
				text_codificat[nr_caract++] = '2';
				text_codificat[nr_caract++] = '2';
				text_codificat[nr_caract++] = '2';
				break;
			}
			case 'd':
			{
				if (i!=0)
					if (text_codificat[nr_caract-1] == '3') 
						text_codificat[nr_caract++] = '#';
				text_codificat[nr_caract++] = '3';
				break;
			}
			case 'D':
			{
				text_codificat[nr_caract++] = '1';
				text_codificat[nr_caract++] = '3';
				break;
			}
			case 'e':
			{
				if (i!=0)
					if (text_codificat[nr_caract-1] == '3') 
						text_codificat[nr_caract++] = '#';
				text_codificat[nr_caract++] = '3';
				text_codificat[nr_caract++] = '3';
				break;
			}
			case 'E':
			{
				text_codificat[nr_caract++] = '1';
				text_codificat[nr_caract++] = '3';
				text_codificat[nr_caract++] = '3';
				break;
			}
			case 'f':
			{
				if (i!=0)
					if (text_codificat[nr_caract-1] == '3') 
						text_codificat[nr_caract++] = '#';
				text_codificat[nr_caract++] = '3';
				text_codificat[nr_caract++] = '3';
				text_codificat[nr_caract++] = '3';
				break;
			}
			case 'F':
			{
				text_codificat[nr_caract++] = '1';
				text_codificat[nr_caract++] = '3';
				text_codificat[nr_caract++] = '3';
				text_codificat[nr_caract++] = '3';
				break;
			}
			case 'g':
			{
				if (i!=0)
					if (text_codificat[nr_caract-1] == '4') 
						text_codificat[nr_caract++] = '#';
				text_codificat[nr_caract++] = '4';
				break;
			}
			case 'G':
			{
				text_codificat[nr_caract++] = '1';
				text_codificat[nr_caract++] = '4';
				break;
			}
			case 'h':
			{
				if (i!=0)
					if (text_codificat[nr_caract-1] == '4') 
						text_codificat[nr_caract++] = '#';
				text_codificat[nr_caract++] = '4';
				text_codificat[nr_caract++] = '4';
				break;
			}
			case 'H':
			{
				text_codificat[nr_caract++] = '1';
				text_codificat[nr_caract++] = '4';
				text_codificat[nr_caract++] = '4';
				break;
			}
			case 'i':
			{
				if (i!=0)
					if (text_codificat[nr_caract-1] == '4') 
						text_codificat[nr_caract++] = '#';
				text_codificat[nr_caract++] = '4';
				text_codificat[nr_caract++] = '4';
				text_codificat[nr_caract++] = '4';
				break;
			}
			case 'I':
			{
				text_codificat[nr_caract++] = '1';
				text_codificat[nr_caract++] = '4';
				text_codificat[nr_caract++] = '4';
				text_codificat[nr_caract++] = '4';
				break;
			}
			case 'j':
			{
				if (i!=0)
					if (text_codificat[nr_caract-1] == '5') 
						text_codificat[nr_caract++] = '#';
				text_codificat[nr_caract++] = '5';
				break;
			}
			case 'J':
			{
				text_codificat[nr_caract++] = '1';
				text_codificat[nr_caract++] = '5';
				break;
			}
			case 'k':
			{
				if (i!=0)
					if (text_codificat[nr_caract-1] == '5') 
						text_codificat[nr_caract++] = '#';
				text_codificat[nr_caract++] = '5';
				text_codificat[nr_caract++] = '5';
				break;
			}
			case 'K':
			{
				text_codificat[nr_caract++] = '1';
				text_codificat[nr_caract++] = '5';
				text_codificat[nr_caract++] = '5';
				break;
			}
			case 'l':
			{
				if (i!=0)
					if (text_codificat[nr_caract-1] == '5') 
						text_codificat[nr_caract++] = '#';
				text_codificat[nr_caract++] = '5';
				text_codificat[nr_caract++] = '5';
				text_codificat[nr_caract++] = '5';
				break;
			}
			case 'L':
			{
				text_codificat[nr_caract++] = '1';
				text_codificat[nr_caract++] = '5';
				text_codificat[nr_caract++] = '5';
				text_codificat[nr_caract++] = '5';
				break;
			}
			case 'm':
			{
				if (i!=0)
					if (text_codificat[nr_caract-1] == '6') 
						text_codificat[nr_caract++] = '#';
				text_codificat[nr_caract++] = '6';
				break;
			}
			case 'M':
			{
				text_codificat[nr_caract++] = '1';
				text_codificat[nr_caract++] = '6';
				break;
			}
			case 'n':
			{
				if (i!=0)
					if (text_codificat[nr_caract-1] == '6') 
						text_codificat[nr_caract++] = '#';
				text_codificat[nr_caract++] = '6';
				text_codificat[nr_caract++] = '6';
				break;
			}
			case 'N':
			{
				text_codificat[nr_caract++] = '1';
				text_codificat[nr_caract++] = '6';
				text_codificat[nr_caract++] = '6';
				break;
			}
			case 'o':
			{
				if (i!=0)
					if (text_codificat[nr_caract-1] == '6') 
						text_codificat[nr_caract++] = '#';
				text_codificat[nr_caract++] = '6';
				text_codificat[nr_caract++] = '6';
				text_codificat[nr_caract++] = '6';
				break;
			}
			case 'O':
			{
				text_codificat[nr_caract++] = '1';
				text_codificat[nr_caract++] = '6';
				text_codificat[nr_caract++] = '6';
				text_codificat[nr_caract++] = '6';
				break;
			}
			case 'p':
			{
				if (i!=0)
					if (text_codificat[nr_caract-1] == '7') 
						text_codificat[nr_caract++] = '#';
				text_codificat[nr_caract++] = '7';
				break;
			}
			case 'P':
			{
				text_codificat[nr_caract++] = '1';
				text_codificat[nr_caract++] = '7';
				break;
			}
			case 'q':
			{
				if (i!=0)
					if (text_codificat[nr_caract-1] == '7') 
						text_codificat[nr_caract++] = '#';
				text_codificat[nr_caract++] = '7';
				text_codificat[nr_caract++] = '7';
				break;
			}
			case 'Q':
			{
				text_codificat[nr_caract++] = '1';
				text_codificat[nr_caract++] = '7';
				text_codificat[nr_caract++] = '7';
				break;
			}
			case 'r':
			{
				if (i!=0)
					if (text_codificat[nr_caract-1] == '7') 
						text_codificat[nr_caract++] = '#';
				text_codificat[nr_caract++] = '7';
				text_codificat[nr_caract++] = '7';
				text_codificat[nr_caract++] = '7';
				break;
			}
			case 'R':
			{
				text_codificat[nr_caract++] = '1';
				text_codificat[nr_caract++] = '7';
				text_codificat[nr_caract++] = '7';
				text_codificat[nr_caract++] = '7';
				break;
			}
			case 's':
			{
				if (i!=0)
					if (text_codificat[nr_caract-1] == '7') 
						text_codificat[nr_caract++] = '#';
				text_codificat[nr_caract++] = '7';
				text_codificat[nr_caract++] = '7';
				text_codificat[nr_caract++] = '7';
				text_codificat[nr_caract++] = '7';
				break;
			}
			case 'S':
			{
				text_codificat[nr_caract++] = '1';
				text_codificat[nr_caract++] = '7';
				text_codificat[nr_caract++] = '7';
				text_codificat[nr_caract++] = '7';
				text_codificat[nr_caract++] = '7';
				break;
			}
			case 't':
			{
				if (i!=0)
					if (text_codificat[nr_caract-1] == '8') 
						text_codificat[nr_caract++] = '#';
				text_codificat[nr_caract++] = '8';
				break;
			}
			case 'T':
			{
				text_codificat[nr_caract++] = '1';
				text_codificat[nr_caract++] = '8';
				break;
			}
			case 'u':
			{
				if (i!=0)
					if (text_codificat[nr_caract-1] == '8') 
						text_codificat[nr_caract++] = '#';
				text_codificat[nr_caract++] = '8';
				text_codificat[nr_caract++] = '8';
				break;
			}
			case 'U':
			{
				text_codificat[nr_caract++] = '1';
				text_codificat[nr_caract++] = '8';
				text_codificat[nr_caract++] = '8';
				break;
			}
			case 'v':
			{
				if (i!=0)
					if (text_codificat[nr_caract-1] == '8') 
						text_codificat[nr_caract++] = '#';
				text_codificat[nr_caract++] = '8';
				text_codificat[nr_caract++] = '8';
				text_codificat[nr_caract++] = '8';
				break;
			}
			case 'V':
			{
				text_codificat[nr_caract++] = '1';
				text_codificat[nr_caract++] = '8';
				text_codificat[nr_caract++] = '8';
				text_codificat[nr_caract++] = '8';
				break;
			}
			case 'w':
			{
				if (i!=0)
					if (text_codificat[nr_caract-1] == '9') 
						text_codificat[nr_caract++] = '#';
				text_codificat[nr_caract++] = '9';
				break;
			}
			case 'W':
			{
				text_codificat[nr_caract++] = '1';
				text_codificat[nr_caract++] = '9';
				break;
			}
			case 'x':
			{
				if (i!=0)
					if (text_codificat[nr_caract-1] == '9') 
						text_codificat[nr_caract++] = '#';
				text_codificat[nr_caract++] = '9';
				text_codificat[nr_caract++] = '9';
				break;
			}
			case 'X':
			{
				text_codificat[nr_caract++] = '1';
				text_codificat[nr_caract++] = '9';
				text_codificat[nr_caract++] = '9';
				break;
			}
			case 'y':
			{
				if (i!=0)
					if (text_codificat[nr_caract-1] == '9') 
						text_codificat[nr_caract++] = '#';
				text_codificat[nr_caract++] = '9';
				text_codificat[nr_caract++] = '9';
				text_codificat[nr_caract++] = '9';
				break;
			}
			case 'Y':
			{
				text_codificat[nr_caract++] = '1';
				text_codificat[nr_caract++] = '9';
				text_codificat[nr_caract++] = '9';
				text_codificat[nr_caract++] = '9';
				break;
			}
			case 'z':
			{
				if (i!=0)
					if (text_codificat[nr_caract-1] == '9') 
						text_codificat[nr_caract++] = '#';
				text_codificat[nr_caract++] = '9';
				text_codificat[nr_caract++] = '9';
				text_codificat[nr_caract++] = '9';
				text_codificat[nr_caract++] = '9';
				break;
			}
			case 'Z':
			{
				text_codificat[nr_caract++] = '1';
				text_codificat[nr_caract++] = '9';
				text_codificat[nr_caract++] = '9';
				text_codificat[nr_caract++] = '9';
				text_codificat[nr_caract++] = '9';
				break;
			}
			case ' ':
			{
				text_codificat[nr_caract++] = '0';
				break;
			}
		}
	}
	*nr=nr_caract;
}

void decodificare (char sir[], char a[10][5])
{
	
	int l_secv = 0, i, CapsLk = 0, j, k; // CapsLk={0->litera mica, 1->litera mare}
	int x;

	
	if (sir[0] >= '2' && sir[0] <= '9')
			l_secv = 1;
	else
		 if (sir[0] == '1')
				CapsLk=1;
	for (i = 1; i < strlen(sir); i++)
	{	if ( sir[i] == sir [i-1]) 
			l_secv++;
		else
			{
				if (sir[i] >= '2' && sir[i] <= '9') 
				{
					if (l_secv > 0)
					{
						x = sir[i-1] - '0'; // transform caracterul s[i] in nr corespunzator
						if (CapsLk==0)
							printf ("%c", a[x][l_secv]);
						else 
							printf ("%c", a[x][l_secv]-32);
					}
				l_secv=1;
				if (sir[i-1] != '1')
						CapsLk=0;
				}
				if (sir[i] == '#')
				{
					if (l_secv > 0)
					{
						x = sir[i-1] - '0'; // transform caracterul s[i] in nr corespunzator
						if (CapsLk==0)
							printf ("%c", a[x][l_secv]);
						else 
							printf ("%c", a[x][l_secv]-32);
					}
					l_secv = 0;
				}

				if (sir[i] == '1')
				{
					if (l_secv > 0)
					{
						x = sir[i-1] - '0'; // transform caracterul s[i] in nr corespunzator
						if (CapsLk==0)
							printf ("%c", a[x][l_secv]);
						else
							printf ("%c", a[x][l_secv]-32);
					}
					l_secv = 0;
					CapsLk = 1;
				}
				if (sir[i] == '0')
				{
					if (l_secv > 0 )
					{
						x = sir[i-1] - '0'; // transform caracterul s[i] in nr corespunzator
						if (CapsLk==0)
							printf ("%c", a[x][l_secv]);
						else printf ("%c", a[x][l_secv]-32);
					}
					printf(" ");
					l_secv = 0 ;
				}
			}
	}
	if (l_secv > 0)
	{
		x = sir[i-1] - '0';
		if (CapsLk == 0)
			printf ("%c", a[x][l_secv]);
		else printf ("%c", a[x][l_secv]-32);
	}
}

int main()
{
	// cerinta1
	char sir[300], text[100], text_codificat[300],i,nr;
	nr=0; //numarul de caractere al textului codificat
	gets(text);
	gets(sir);
	codificare(text, text_codificat, &nr);
	text_codificat[nr]=NULL;
	printf("%s\n", text_codificat);

	// cerinta2
	char a[10][5], c='a';
	int j;
	for (i=2; i<=9; i++)
		if (i==7 || i==9)
			for (j=1; j<=4; j++)
			{
				a[i][j]=c;
				c++;
			}
		else for (j=1; j<=3; j++)
			{
				a[i][j]=c;
				c++;
			}
	decodificare(sir, a);
	return 0;
}