#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
	int* v; //adresa vector
	int cap; // dimensiune alocata maxima
	int n; //dimensiune efectiva (numar de intregi stocati)
}vector;

void init_vector(vector* a, int nr)
{
	a->v = malloc(nr * sizeof(int));
}

void adauga_vector(vector* a, int x)
{
	if (a->n == a->cap)
	{
		(a->cap) *= 2;
		a->v = realloc(a->v, a->cap * sizeof(int));
	}
	a->v[a->n] = x;
	(a->n)++;

}

void scrie_vector(vector a)
{
	int i;
	for (i = 0; i < a.n; i++)
		printf("%d", a.v[i]);
}

int main()
{
	int i;
	vector a;
	a.n = 0; // nr de intregi stocati initial in vector
	a.cap = 10; // dimensiunea maxima
	init_vector(&a, a.cap);

	for (i=0; i<=100; i++)
		adauga_vector(&a, i);

	for (i=0; i < a.n; i++)
		printf("%d ", a.v[i]);
	return 0;
}