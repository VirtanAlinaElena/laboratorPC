#include <stdio.h>

typedef struct {
	float re;
	float im;
} complex;

complex adunare(complex a, complex b)
{
	complex c;
	c.re = a.re + b.re;
	c.im = a.im + b.im;
	return c;

}

complex inmultire(complex a, complex b)
{
	complex c;
	c.re = a.re * b.re - a.im * b.im;
	c.im = a.re * b.im + a.im * b.re;
	return c;
}

complex inmul_coef(float c, complex a)
{
	complex b;
	b.re = c * a.re;
	b.im = c * a.im;
	return b;
}

complex putere(complex a, int coef)
{
	int i;
	complex c;
	if (coef==0) 
	{
		c.re=1;
		c.im=0;
		return c;
	}
		else if (coef >= 2)
		{
			c = inmultire (a,a);
			for (i=0; i<coef-2; i++)
				c = inmultire(c, a);
			return c;
		}
}
void scrie(complex a)
{
	printf("(%.2f, %.2f)", a.re, a.im);
}
 int main()
 {
 	complex c, termen;
 	c.re=0;
 	c.im=0;
 	float Re, Im, x;
 	int G, i, coef;
 	coef=0;
 	scanf("%f %f", &Re, &Im);
	scanf("%d", &G);
 	
 	for (i=0; i<=G; i++)
 	{
 		scanf("%f", &x); // citesc coeficientii polinomului, de la c_0 la c_G
 		termen.re=Re;
 		termen.im=Im;
 		if (i!=1)
 			termen=putere(termen, coef);
 		termen=inmul_coef(x, termen);
 		c=adunare(c, termen);
 		coef++;
 	}
 	scrie(c);
 }