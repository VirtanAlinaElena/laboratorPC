#include <stdio.h>
#include <time.h>

typedef struct {
    int ora, min, sec;
} time;

int cmptime (time t1, time t2)
{
    int d;
    d=t1.ora-t2.ora;
    if (d!=0) return d; // returneaza <0 daca t1<t2 si >0 daca t1>t2
    d=t1.min-t2.min;
    if (d!=0) return d; // returneaza <0 daca t1<t2 si >0 daca t1>t2
    d=t1.sec-t2.sec;
    if (d!=0) return d;
    return 0; // returneaza 0 daca t1=t2
}

int corect (time t) 
{
    if (t.ora < 0 || t.ora > 23) return 0; // formatului timpului e incorect
    if (t.min < 0 || t.min > 59) return 0; // formatul timpului e incorect
    if (t.sec < 0 || t.sec > 59) return 0; // formatul timpului e incorect
    return 1; // formatul timpului e unul corect
}

time rdtime () // citire ora
{
    time t;
    do {
        scanf("%d%d%d", &t.ora, &t.min, &t.sec);
        if ( ! corect(t) )
            printf ("Date gresite, repetati introducerea: \n");
        else return t;
    } while( corect(t) == 0 );
}

void wrtime (time t)
{
    printf ("%02d:%02d:%02d\n", t.ora,t.min,t.sec);
}

void sort (time a[], int n)
{
    int i,gata;
    time aux;
    do {
        gata = 1; // pp ca vectorul de date e ordonat
        for (i=0; i<n-1; i++)
            if ( cmp(a[i], a[i+1]) ) {
                aux=a[i];
                a[i]=a[i+1];
                a[i+1]=aux;
                gata = 0;
            }
    } while (! gata);
}

int main()
{
    time t[30];
    int n,i;
    scanf("%d", &n);
    for (i=0; i<n; i++) t[i]=rdtime();
    sort(t, n);
    for (i=0; i<n; i++) wrtime(t[i]);
    return 0;
}