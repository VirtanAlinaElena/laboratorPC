#include <stdio.h>
#include <time.h>

int main()
{
	time_t rawtime;
	struct tm* timeinfo;
	time(&rawtime); // ora curenta ca numar de secunde
	printf("Current local time and date from time_t->string: %s", ctime(&rawtime)  );
	printf("\n");
	timeinfo = localtime(&rawtime);
	printf ("Current local time and date from struct tm->string: %s", asctime(timeinfo));
	return 0;
}