#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

char* timestr(struct tm t, char* time)
{
	 sprintf(time, "%02d:%02d:%02d", t.tm_hour, t.tm_min, t.tm_sec);
}

int main()
{
	struct tm t;
	char *time=malloc(100*sizeof(char));
	scanf("%d%d%d", &t.tm_hour, &t.tm_min, &t.tm_sec);

	timestr(t, time);
	printf("%s\n", time);
	time=realloc(time, strlen(time)*sizeof(char));
}