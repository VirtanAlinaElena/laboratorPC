#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
	char sir[100];
	int *v; // vectorul de numere intregi
	v = (int*) malloc (100*sizeof(int));
	int n=0; // numarul de cuvinte distincte
	char** a = malloc(100*sizeof(char*)); // matricea de cuvinte
	int i;
	scanf("%s", sir);
	while ( strcmp(sir, "exit") != 0)
	{
		if (n==0)
		{
			a[0] = strdup(sir);
			v[0]=1;
			n++;
		}
			else 
			{
				a[n] = strdup(sir);
				int OK, poz;
				OK=0;
				for (i=0; i<n && OK==0; i++)
					if ( strcmp(sir, a[i]) == 0 ) 
					{
						OK=1;
						poz=i;
					}
				if (OK==1) v[poz]++;
					else
					{
						strcpy(a[n], sir);
						v[n]=1;
						n++;
					}
				a[n] = (char*) realloc (a[n], (strlen(a[n])+1)*sizeof(char));
			}
		
		scanf("%s", sir);
	}
	for (i=0; i<n; i++)
		printf("%s %d", a[i], v[i]);
	v = realloc (v, n*sizeof(int));
	a = realloc(a, n*sizeof(char*));
}