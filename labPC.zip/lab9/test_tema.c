#include <stdio.h>
#include <string.h>
int main()
{
	char s[50];
	fgets(s, 50, stdin);
	printf("%d", (int)strlen(s));
}