#include <stdio.h>
#include <string.h>
#include <stdlib.h>

typedef struct {
	char *s1, *s2;
} pereche;

void codificare(char text[], char a[][5], char textcod[], int* nr_caract)
{
	int k,i,j,t,tasta,nr;
	tasta = 0;
	nr = 0;
	for (k = 0; k < strlen(text); k++)
	{
		if (text[k] == ' ')
		{	
			textcod[nr++] = '0';
			tasta=0;
		}
		for (i=2; i<=9; i++)
			if (i == 7 || i == 9)
				for (j = 1; j <= 4; j++) 
				{
					if (text[k] == a[i][j]-32) 
					{
						tasta = i;
						textcod[nr++] = '1'; // litera mare
						for (t = 1; t <= j; t++)
							textcod[nr++] = i + '0';
					}
					if (text[k] == a[i][j])
					{
						if (i == tasta)
							textcod[nr++] = '#';
						for (t = 1; t <= j; t++)
							textcod[nr++] = i + '0';
						tasta = i;
					}

				}
			else
				for (j = 1; j <= 3; j++) 
				{
					if (text[k] == a[i][j]-32) 
					{
						tasta = i;
						textcod[nr++] = '1'; // litera mare
						for (t = 1; t <= j; t++)
							textcod[nr++] = i + '0';
					}
					if (text[k] == a[i][j])
					{
						if (i == tasta)
							textcod[nr++] = '#';
						for (t = 1; t <= j; t++)
							textcod[nr++] = i + '0';
						tasta = i;
					}
				}
	}
	*nr_caract = nr;
}

void decodificare (char sir[], char a[][5])
{
	
	int l_secv = 0, i, CapsLk = 0, j, k; // CapsLk={0->litera mica, 1->litera mare}
	int x;

	
	if (sir[0] >= '2' && sir[0] <= '9')
			l_secv = 1;
	else
		 if (sir[0] == '1')
				CapsLk=1;
	for (i = 1; i < strlen(sir); i++)
	{	if ( sir[i] == sir [i-1]) 
			l_secv++;
		else
			{
				if (sir[i] >= '2' && sir[i] <= '9') 
				{
					if (l_secv > 0)
					{
						x = sir[i-1] - '0'; // transform caracterul s[i] in nr corespunzator
						if (CapsLk==0)
							printf ("%c", a[x][l_secv]);
						else 
							printf ("%c", a[x][l_secv]-32);
					}
				l_secv=1;
				if (sir[i-1] != '1')
						CapsLk=0;
				}
				if (sir[i] == '#')
				{
					if (l_secv > 0)
					{
						x = sir[i-1] - '0'; // transform caracterul s[i] in nr corespunzator
						if (CapsLk==0)
							printf ("%c", a[x][l_secv]);
						else 
							printf ("%c", a[x][l_secv]-32);
					}
					l_secv = 0;
				}

				if (sir[i] == '1')
				{
					if (l_secv > 0)
					{
						x = sir[i-1] - '0'; // transform caracterul s[i] in nr corespunzator
						if (CapsLk==0)
							printf ("%c", a[x][l_secv]);
						else
							printf ("%c", a[x][l_secv]-32);
					}
					l_secv = 0;
					CapsLk = 1;
				}
				if (sir[i] == '0')
				{
					if (l_secv > 0 )
					{
						x = sir[i-1] - '0'; // transform caracterul s[i] in nr corespunzator
						if (CapsLk==0)
							printf ("%c", a[x][l_secv]);
						else printf ("%c", a[x][l_secv]-32);
					}
					printf(" ");
					l_secv = 0 ;
				}
			}
	}
	if (l_secv > 0)
	{
		x = sir[i-1] - '0';
		if (CapsLk == 0)
			printf ("%c", a[x][l_secv]);
		else printf ("%c", a[x][l_secv]-32);
	}
	printf("\n");
}

void auto_correct(char text[], int n, pereche* v, char a[][5])
{
	int i;

	char *p, *aux1, *aux2;
	char textcodif[300];
	int nr_crct = 0;
	//corectarea textului dat
	for (i=0; i<n; i++)
	{
		p=strstr(text, v[i].s1);
		while (p!=NULL)
		{
			aux1=malloc(100*sizeof(char));
			strncpy(aux1, text, p-text);
			aux1[p-text]='\0';
			aux2=strdup( p + strlen(v[i].s1));
			strcat (aux1, v[i].s2);
			strcat (aux1, aux2); 
			strcpy(text, aux1);
			p = strstr ( p + strlen(v[i].s2), v[i].s1);
		}	
	}
	//criptarea textului corectat
	codificare(aux1,a,textcodif,&nr_crct);
	textcodif[nr_crct] = '\0';
	printf("%s\n", textcodif);
}

int numar_componente(char text[])
{
	int nr_componente = 1;
	int i;
	for (i = 0; i < strlen(text); i++)
	{
		if (text[i] == ' ')
			nr_componente++;
	}
	return nr_componente;

}

long long cmmdc(long long x, long long y)
{
	long long R;
	R = x % y;
	while (R)
	{
		x = y;
		y = R;
		R = x % y;
	}
	return y;
}

void prim (long long componente[], int n)
{
	int ok,i,j;
	ok = 1; // presupun ca mesajul este prim
	for (i = 0 ; i < n-1 && ok == 1; i++)
		for (j = i+1; j < n & ok == 1; j++)
			if (cmmdc( componente[i], componente[j]) != 1) 
				ok = 0;
	printf ("%d\n", ok); // ok=1 - mesaj prim, ok=0 - mesajul e nu prim
}

int main()
{
	//declaratii
	int n, i, j;
	char text1[100], text2[100], text3[100], sir[300], cuvant[300];

	//formez matricea cu tastele
	char a[10][5], c = 'a';
	for (i=2; i<=9; i++)
		if (i==7 || i==9)
			for (j=1; j<=4; j++)
			{
				a[i][j]=c;
				c++;
			}
		else 
			for (j=1; j<=3; j++)
			{
				a[i][j]=c;
				c++;
			}

	//citire si initializare
	fgets(text1, 100, stdin);

	scanf("%s\n", sir);

	fgets(text2, 100, stdin);
	scanf("%d\n", &n);
	pereche* v = (pereche *)malloc(n*sizeof(pereche));
	for (i=0; i<n; i++)
	{
		scanf("%s ", cuvant);
		v[i].s1 = strdup(cuvant);
		scanf("%s\n", cuvant);
		v[i].s2=strdup(cuvant);
	}

	fgets(text3, 100, stdin);

	// cerinta1
	int nr_caract = 0;
	char textcod[300];
	codificare(text1, a, textcod, &nr_caract);
	textcod[nr_caract] = '\0';
	printf("%s\n", textcod);

	// cerinta2
	decodificare(sir, a);

	// cerinta3
	auto_correct(text2,n,v,a);

	// cerinta4
		//afisez nr de componente
	int nr_componente = numar_componente(text3);
	printf("%d\n", nr_componente);

		//verific daca mesajul e prim
	//prim(componente, nr_componente);

	return 0;
}