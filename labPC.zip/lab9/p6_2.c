#include <stdio.h>
#include <string.h>
#include <stdlib.h>
typedef struct {
	char cuv[100];
	int ap;
} pereche;

int main()
{
	int i,n;
	char sir[100];
	n=0; // numarul de inregistrari
	pereche* v;
	v = malloc(100*sizeof(pereche));
	scanf ("%s", sir);

	while ( strcmp(sir, "exit") !=0 ) 
	{	
		if (n==0)
		{
			strcpy (v[0].cuv, sir);
			v[0].ap=1;
			n++;
		}
		else
		{
			int OK, poz;
			OK=0; // pp ca sirul nu e in vector
			for (i=0; i<n && OK==0; i++)
				if ( strcmp(sir, v[i].cuv ) == 0 ) 
					{
						OK=1;
						poz=i;
					}
			if (OK==1)
					v[poz].ap++;				    	
				else 
				{
					strcpy (v[n].cuv, sir);
					v[n].ap=1;
					n++;
				}
		}
		scanf ("%s", sir);
	}
	for (i=0; i<n; i++)
		printf("%s %d\n", v[i].cuv, v[i].ap);
	v = realloc(v, n*sizeof(pereche));
	return 0;
}