#include <stdio.h>

int main()
{
	int n,s,x,nrcif,k,i;
	scanf("%d", &n);
	nrcif=0;
	for (i=1; i<=n; i++)
	{
		x=i;
		k=0;
		while (x!=0)
		{
			k++;
			x/=10;
		}
		nrcif+=k;
	}
	printf("%d\n", nrcif);
}