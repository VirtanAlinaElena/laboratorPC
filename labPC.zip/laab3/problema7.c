#include <stdio.h>
#include <math.h>
int main()
{
	double EPS,x,t1,t2,s1,s2;
	int n,i,k;
	scanf("%lf %d %lf", &x, &n, &EPS);
	t1=1;
	s1=t1;
	for (k=1; k<=n-1; k++)
		{
			t1*=x/k;
			s1+=t1;
		}	

	t1=1;
	s2=1;
	k=1;
	while (t1>EPS)
	{
		t1=t1*x/k;
		s2+=t1;
		k++;
	}
	printf( "%lf %lf %lf %lf", s1, s2, exp(x), pow(2.718,x) );
	return 0;
}