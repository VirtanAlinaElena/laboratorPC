#include <stdio.h>

int main()
{
	char ch=' ';
	int i;
	for (i=1; i<=96; i++)
	{
		printf("%c = %d ", ch, ch);
		ch++;
		if ( i%10==0 ) printf ("\n");
	}
	printf("\n");
}