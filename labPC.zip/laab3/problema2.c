#include <stdio.h>

int main()
{
	int k=0,n,m,i;
	scanf("%d%d", &n, &m);
	for (i=1; i<=n; i++)
	{
		if (i%m==0)
		{
			printf("%d\n", i);
			k++;
		}
			else printf("%d ", i);
		if (k==24) printf("\n");
	}
	printf ("\n");
	return 0;
}