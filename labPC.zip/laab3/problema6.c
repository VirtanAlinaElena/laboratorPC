#include <stdio.h>

int main()
{
	int n,m,c1,c2,i,fact1,fact2,fact3,k;
	scanf("%d%d", &n, &m);
	//mod 1
	c1=1;
	for (k=1; k<=m; k++)
		c1*=(n-k+1)/k;
	printf("%d\n", c1);

	//mod 2
	fact1=fact2=fact3=1;
	for (i=1; i<=n; i++)
		fact1*=i;
	for (i=1; i<=m; i++)
		fact2*=i;
	for (i=1; i<=n-m; i++)
		fact3*=i;
	c2=fact1/(fact2*fact3);
	printf("%d\n", c2);
	return 0;
}