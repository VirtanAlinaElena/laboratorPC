#include <stdio.h>

int main()
{
	int i,j,P;
	scanf("%d", &P);
	for (i=1; i<=P/2; i++)
		for (j=1; j<=P/2; j++)
			if (i<=j && j<=P-i-j)
				if (i<j+(P-i-j) && j<i+(P-i-j) && P-i-j<i+j)
					printf ("%d %d %d\n", i, j, P-i-j);
	return 0;
}