#include <stdio.h>

int main()
{
	int n,i,j;
	float x,sx;
	double y,sy;
	scanf("%d%f%lf", &n, &x, &y);
	sx=sy=0;
	for (i=1; i<=n; i+=n/10)
	{
		for (j=1; j<=n/10; j++)
		{
			sx+=x;
			sy+=y;
		}
		printf ("%f %e %f %e\n", sx, sx, sy, sy);

	}
	return 0;
}