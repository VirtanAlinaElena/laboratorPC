#include <stdio.h>
int max(int a, int b)
{
	int Max;
	if (a>b) 
		Max=a;
	else Max=b;
	return Max;
}
int min(int a, int b)
{
	int Min;
	if (a<b)
		Min=a;
	else Min=b;
	return Min;
}

int arie_intersectie(int x11, int y11, int x12, int y12, int x21, int y21, int x22, int y22)
{
	int dr1_stanga=min(x11,x12);
	int dr2_stanga=min(x21,x22);
	int dr1_dreapta=max(x11,x12);
	int dr2_dreapta=max(x21,x22);
	int dr1_sus=max(y11,y12);
	int dr2_sus=max(y21,y22);
	int dr1_jos=min(y11,y12);
	int dr2_jos=min(y21,y22);
	int stanga=max(dr1_stanga, dr2_stanga);
	int dreapta=min(dr1_dreapta, dr2_dreapta);
	int sus=min(dr1_sus, dr2_sus);
	int jos=max(dr1_jos, dr2_jos);
	if (stanga<dreapta && jos<sus)
		return ("%d", (dreapta-stanga)*(sus-jos) );
	else
		return 0;


}
int main()
{
	int x11,y11,x12,y12,x21,y21,x22,y22;
	scanf("%d %d %d %d %d %d %d %d", &x11, &y11, &x12, &y12, &x21, &y21, &x22, &y22);
	printf ( "%d\n", arie_intersectie(x11, y11, x12, y12, x21, y21, x22, y22) );
	return 0;
}