#include <stdio.h>

int transformat (int n)
{
	int c,v[12],i,nr,j;
	nr=0;
	for (i=0; i<=9; i++)
		v[i]=0;
	while (n)
	{
		c=n%10;
		v[c]++;
		n/=10;
	}
	if ( v[0]!=0 )
		for (i=9; i>=0; i--)
			for (j=1; j<=v[i]; j++)
				nr=nr*10+i;
	else 
		for (i=1; i<=9; i++)
			for (j=1; j<=v[i]; j++)
				nr=nr*10+i;
	return nr;
}
int main()
{
	int n,nr;
	scanf("%d", &n);
	nr=transformat(n);
	printf ("%d\n", nr);
	return 0;
}