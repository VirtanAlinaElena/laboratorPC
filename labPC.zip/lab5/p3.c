#include <stdio.h>

int prim(int n)
{
	int divizor;

	if (n <= 1)
		return 0;

	divizor = 2;

	while (divizor * divizor <= n)
		if (n % divizor == 0) 
			return 0;
		else divizor++;
	return 1;
}

int main()
{
	int n, i,x,y;
	scanf ("%d", &n);
	for (i = 1; i <= n/2; i++)
	{
		x=i;
		y=n-i;
		if ( prim(x) == 1 && prim(y) == 1)
			printf("%d+%d\n", x,y);
	}
}
