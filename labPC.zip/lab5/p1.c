#include <stdio.h>

int cifra(int n, int c)
{
	int OK,cif;
	OK=0;
	while (n!=0)
	{
		cif=n%10;
		if (cif==c) OK=1;
		n/=10;
	}
	return OK;
}
int main()
{
	int n,c,OK;
	scanf ("%d %d", &n, &c);
	OK=cifra(n,c);
	if (OK==1) printf("DA\n");
		else printf("NU\n");
}
