#include <stdio.h>

int factorial (int n)
{
	long int i,fact;
	if (n==0) fact=1;
	else
	{
		fact=1;
		for (i=1; i<=n; i++) fact=fact*i;
	}
	return fact;
}

double putere (double x, int n)
{
	int i;
	float p=1;
	if (n==0) p=1;
	else
		for ( i=0; i<n; i++ )
			p = p * x;
	return p;
}
double taylor(double x, int n)
{
	int i;
	float s=0;
	for (i=0; i<=n; i++)
		s = s + putere(x,i)/factorial(i);
	return s;
}
int main()
{
	int n;
	float x;
	scanf ("%f %d", &x, &n);
	printf( "%.4f\n", taylor(x,n) );
	return 0;
}