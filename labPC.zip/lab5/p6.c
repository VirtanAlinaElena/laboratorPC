#include <stdio.h>
#include <math.h>

float dist(int x1, int y1, int x2, int y2)
{
	int a[101], b[101];
	float d;
	d = sqrt ( (x1-x2)*(x1-x2) + (y1-y2)*(y1-y2));
	return d;
}
int main()
{
	int x1,x2,y1,y2,n,i,j,a[101],b[101];
	float d,dmax;
	scanf("%d", &n);
	for (i=0; i<n; i++)
		scanf ("%d  %d", &a[i], &b[i]);
	for (i=0; i<n-1; i++)
		for (j=i+1; j<n; j++)
		{
			d = dist ( a[i], b[i], a[j], b[j] );
			if ( d > dmax )
			{
				x1=a[i];
				y1=b[i];
				x2=a[j];
				y2=b[j];
				dmax=d;
			}
		}
	printf ("%d %d\n", x1, y1);
	printf ("%d %d\n", x2, y2);
	printf ("%f\n", dmax);
	return 0;
}