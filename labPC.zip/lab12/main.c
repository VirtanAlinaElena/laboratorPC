#include "Produs.h"

void creare_fisier(char* nume_fisier)
{
	Produs produs[100];
	int i, X;
	char sir2[100];
	for (i=0; i<100; i++)
	{
		char sir1[1000]="Produs";
		X = rand();
		sprintf(sir2, "%d", X);
		strcat(sir1, sir2); 
		strcpy(produs[i].nume_produs, sir1);
		produs[i].cantitate = X % 100;
		produs[i].pret_produs = X <= 100 ? X : X % 100;
	}
	
	FILE* b;
	b = fopen("nume_fisier", "wb");
	fwrite(produs, sizeof(Produs), 100, b);
	fclose(b);
}

void afisare_ecran(char* nume_fisier)
{
	FILE *b;
	int i;
	b = fopen("nume_fisier", "rb");
	Produs produs[100];
	fread(produs, sizeof(Produs), 100, b);
	for (i = 0; i < 100; i++)
	{
		printf("%s %d %f", produs[i].nume_produs, produs[i].cantitate, produs[i].pret_produs);
		printf("\n");
	}
	fclose(b);

	/*
	for (i = 0; i < 100; i++)
	{
		fread(&produs[i], sizeof(Produs), 1, b);
	}
	*/
}

void sortare(char* nume_fisier)
{
	Produs produs[100];
	FILE *b;
	b = fopen("nume_fisier", "rb");
	fread(produs, sizeof(Produs), 100, b);
	
	int ok, i;
	char aux[20];
	while (ok == 0) 
	{
		ok = 1; // presupunem ca e sortat
		for (i = 0; i < 99; i++)
			if (strcmp(produs[i].nume_produs, produs[i+1].nume_produs) > 0 )
			{
				ok = 0;
				strcpy(aux, produs[i].nume_produs);
				strcpy(produs[i].nume_produs, produs[i+1].nume_produs);
				strcpy(produs[i+1].nume_produs, aux);
			}
	}
	fclose(b);

	b = fopen("nume_fisier", "wb");
	fwrite(produs, sizeof(Produs), 100, b);
	fclose(b);
}

int p5(char* nume_fisier)
{
	char nume[20];
	int i;
	Produs produs[100];
	scanf("%s", nume);

	FILE* b;
	b = fopen("nume_fisier", "rb");
	fread(produs, sizeof(Produs), 100, b);
	int ok = 1;
	for (i = 0; i < 100 && ok == 1; i++)
		if (strcmp(nume, produs[i].nume_produs) == 0)
		{
			ok = 0;
			printf("%s %d %f\n", produs[i].nume_produs, produs[i].cantitate, produs[i].pret_produs);
		}
	if (ok == 1)
		printf("Nu exista produsul\n");
	fclose(b);
}

int p6(char* nume_fisier, Produs produs[100])
{
	char nume[20];
	int i;
	scanf("%s", nume);

	FILE *b;
	b = fopen("nume_fisier", "rb");
	fread(produs, sizeof(Produs), 100, b);
	int ok = 1;
	long int poz;
	for (i = 0; i < 100 && ok == 1; i++)
		if (strcmp(nume, produs[i].nume_produs) == 0)
		{
			ok = 0;
			poz = ftell(b);
			printf("%s %d %f\n", produs[i].nume_produs, produs[i].cantitate, produs[i].pret_produs);
		}
	if (ok == 1)
		printf("Nu exista produsul\n");
	else
	{
		char sir1[1000]="Produs";
		X = rand();
		sprintf(sir2, "%d", X);
		strcat(sir1, sir2); 
		strcpy(produs[nr].nume_produs, sir1);
		produs[nr].cantitate = X % 100;
		produs[nr].pret_produs = X <= 100 ? X : X % 100;
	}

}


int main(int argc, char** argv)
{
	Produs produs[100];
	creare_fisier("nume_fisier");
	p6("nume_fisier");
}
