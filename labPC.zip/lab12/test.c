#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
	int x;
	x = rand();
	char sir[100]="Produs", sir2[100];
	sprintf(sir2, "%d", x);
	strcat(sir, sir2);
	printf("%s", sir);
	return 0;


}
