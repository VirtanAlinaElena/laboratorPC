#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
	char nume_produs[20];
	int cantitate;
	float pret_produs;
} Produs;

void creare_fisier(char* nume_fisier);
void afisare_ecran(char* nume_fisier);