#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define MAX_VALUE 200

int cmp(const void * a, const void *b)
{
   return (*(int*)a - *(int*)b);
}

int* cauta(int* x, int *v, int N)
{	
        // int cauta(int x, int *v, int N)
	// {
	//	int *p;
  	//	p = (int*) malloc(sizeof(int));
	//	*p = x;
	// 	int* t;
	// 	t = (int*) bsearch(p, v, N, sizeof(int), cmp);
	// }
	// int main()
	// ... cauta(x, v, N); ...
	
	int* t;
	t = (int*) bsearch(x, v, N, sizeof(int), cmp);
	return t;	
}

int main(void)
{
   int N, i;
   int *v;
   printf("Introduceti dimensiunea vectorului:\n");
   scanf("%d", &N);
 
   v = calloc(N, sizeof(int));
   if (!v) printf("Nu am putut aloca memorie pentru v!\n");
 
   srand(time(NULL));
   for (i = 0; i < N; ++i)
      v[i] = (rand() % MAX_VALUE)+1;

   for (i = 0; i < N; ++i)
      printf("%d ", *(v+i));
   printf("\n");%
 
   qsort(v, N, sizeof(int), cmp);
 
   for (i = 0; i < N; ++i)
      printf("%d ", *(v+i));
   printf("\n");
    
   int x;
   scanf("%d", &x);
   int* t;
   t = cauta(&x, v, N);
   if (t == NULL )
	   printf("NULL\n");
   else
   	   printf("%ld\n", t - v + 1);
	   

   free(v);
   return 0;
}
