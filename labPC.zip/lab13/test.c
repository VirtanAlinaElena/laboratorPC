#include <stdio.h>
#include <stdlib.h>
int main()
{
	int x;
	int *a;
	scanf("%d", &x);
        a = malloc(sizeof(int));
        *a = x;
	printf("%d", *a);	
	printf("\n%ld\n%ld", sizeof(int), sizeof(char));
	return 0;
}
