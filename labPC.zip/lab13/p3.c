#include <stdio.h>
#include <stdlib.h>

typedef struct {
	void * key;
	void * value;
} entry;

typedef struct { 
	entry ** elem; // vectorul de elemente alocat si realocat dinamic
	int n_elem;
	int cap;
} map;

// aloca initial memorie pentru cap elemente de tip entry*
void init(map *m, int cap)
{
	m->elem = malloc(cap*sizeof(*entry);
	m->n_elem = 0;
	m->cap = cap;
}


// adauga la vectorul de elemente din m noua intrare (pointerul primit) si eventual realoca pe m-elem 
void add(map *m, entry *e)
{
	if (m->cap < m->n_elem)
	{
		m->cap = m->cap * 2;
		m->elem = realloc(m->elem, m->cap * sizeof(*entry));  
	}

	int i;
	ok = 1; // pp ca nu exista chei duplicate
	for (i = 0; i < m->n_elem && ok == 0; i++)
	{
		if (m->elem[i]->key == e->key) 
			ok = 0;
	}
	if (ok == 1)
	{
		m->elem[m->n_elem] = e;
		m->n_elem++;
	}
}

// afiseaza pe m folosind functia pentru afisarea unui entry primita ca parametru
void print(map *m, void ( *printEntry) (const entry * ) )
{
	int i;
	for (i = 0; i < m->n_elem; i++)
		printEntry(m->elem[i]);

}

// sorteaza elementele din m folosind functia primita ca parametru si functia de biblioteca qsort. Observatie: fc va trebui sa compare între ele 2 structuri entry* (se va face conversie la entry ** in functia de comparatie!! DE CE?)
void sort(map *m, int ( * fc ) (const void *, const void *))
{
	qsort(m->elem, m->n_elem, sizeof(entry*), fc);
}

// sterge intrarea corespunzatoare cheii k din m. Atentie! Nu veti compara pointerii pentru a testa daca 2 elemente sunt egale, ci veti folosi functia primita ca parametru, ce se considera ca întoarce 0 pentru elemente egale. Observatie: fc2 va trebui sa compare între ele 2 chei (void *).
void del(map *m, void *k, int (*fc2) (const void *, const void *))
{
	(char *)key1 = (char*)k;
	for (i = 0; i < m->n_elem; i++)
		if ( fc2(m->elem[i]->key, k) == 0 )
			free(m->elem[i]->key);
			si pt value
			for (j = i +1; j < n_elem;0; j++, i++)
				m->elem[i] = m->elem[j];
}

// functie ce întoarce valoarea asociata unei chei. Se va folosi functia bsearch! Observatie: fc va trebui sa compare între ele 2 structuri entry* (se va face conversie la entry ** in functia de comparatie!! DE CE?). Vectorul tb sortat in prealabil! Dar, atentie el nu tb sa iasa modificat, se va lucra pe o copie a lui!
void *find(map *m, void *k, int (*fc) (const void *, const void *))
{
}

//  Funcţia ce compară între ele 2 structuri entry* ţinând cont de faptul că în acest caz particular cheia va fi char *. Funcţia de comparare nu trebuie să ţină cont şi de valorile asociate.
int compareEntry(const void *a, const void *a)
{
	entry** e1 = (entry **)a;
	entry** e2 = (entry **)b;
	return strcmp((*e1)->key, (*e2)->key);
}

// Funcţie ce compară 2 chei (în cazul de faţă, 2 şiruri de caractere). Funcţia va apela _strcmp_.
int compareKey(const void *a, const void *b)
{
	char* key1 = (char*)a;
	char* key2 = (char*)b; 
	return strcmp(key1, key2);
}

// Funcţie ce afişează cheia şi valoarea asociată pe cazul particular când sunt şiruri de caractere.
int printEntry(const entry *e)
{
	printf("%s", (char*)e->key);
	printf("%s", (char*)e->value);
}

int main()
{
	return 0;
}
