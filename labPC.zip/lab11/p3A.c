#include <stdio.h>
#include <string.h>
#define BUFMAX 1005

int main(int argc, char** argv)
{
	FILE *dest;
	int i;
	char buffer[BUFMAX];

	dest = fopen (argv[1], "r");
	if ( !dest )
	{
		printf("Eroare! Nu am putut deschide fisierul destinaite!\n");
		return 0;
	}
	else
	{
		while (fgets(buffer, BUFMAX, dest) != NULL)
		{	if (strstr(buffer, argv[2]) != NULL)
				printf("%s", buffer);
		}
		fclose (dest);
	}
}
