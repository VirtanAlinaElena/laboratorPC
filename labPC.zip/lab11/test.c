#include <stdio.h>

#define BUFMAX 1005

int main(int argc, char **argv)
{
	FILE * pFile;
	char buffer [BUFMAX];

	pFile = fopen("input.txt", "r");
	if (pFile  == NULL)
		fprintf(stderr, "Eroare! Nu am putut deschide fisierul!");
	else
	    {
		char c;
		c = fgetc(pFile);
		while (c != EOF)
		{
			fputc(c, stdout);
			c=fgetc(pFile);
		}
		fclose(pFile);
	    }
	return 0;
}
