#include <stdio.h>
#include <string.h>
#define BUFMAX 1005

int main(int argc, char** argv)
{
	FILE *dest, *src, *aux;
	char buffer[BUFMAX], c;
	int ok;
	dest = fopen(argv[3], "w");
	if (!dest)
	{
		fprintf(stderr, "Eroare! Nu am putut deschide fisierul destinatie!\n");
		return 0;
	}
   	 src = fopen(argv[2], "r");
   	 if (!src)
     	 {
        	fprintf(stderr, "Eroare! Nu am putut deschide fisierul sursa!\n");
        	return 0;
    	 }
	 else
	 {
		 c = fgetc(src);
		 while (c != EOF)
		 {	
			 aux = fopen(argv[1], "r");
			 if (!aux) 
			 { 
				 fprintf(stderr, "Eroare! Nu am putut deschide tabela de codare!\n");
				 return 0;
			 }
			 else
			 {
				ok = 0; // pp ca nu exista codificare pentru caracterul c
				while (fgets(buffer, BUFMAX, aux) != NULL && ok == 0)
			       		if (buffer[0] == c)	
					{	ok = 1; // exista codificare pentru c
						fputc(buffer[2], dest);
						
					}
					else
						if (buffer[0]-32 == c)
						{
							ok = 1;
							fputc(buffer[2]-32, dest);
						}
				if (ok == 0)
					fputc(c, dest);
				fclose(aux);
			 }
 			 c = fgetc(src);
		}

		fclose(src);
	 }
	 fclose(dest);
	return 0;
}
