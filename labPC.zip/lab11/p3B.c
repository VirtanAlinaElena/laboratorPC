#include <stdio.h>
#include <string.h>
#define BUFMAX 1005

int main(int argc, char** argv)
{
	FILE *dest;
	char buffer[BUFMAX];
	int i = 0, k = 0;
	dest = fopen (argv[argc-2], "r");
	if ( !dest )
	{
		printf("Eroare! Nu am putut deschide fisierul destinaite!\n");
		return 0;
	}
	else
	{
		while (fgets(buffer, BUFMAX, dest) != NULL)
		{	i++;
			if (strcasestr(buffer, argv[argc-1]) != NULL)
			{	printf("[");
				printf("%d", i);
				printf("] ");
				printf("%s", buffer);
				k++;
			}
		}
		fclose (dest);
	}
	printf("Numar total de linii: %d\n", k);
}
