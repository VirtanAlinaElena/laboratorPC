#include <stdio.h>

void  bubbleSort (int n, int v[])
{
	int ok=0, i, aux;
	while (ok==0) {
		ok=1; // pp ca e sortat
		for (i=0; i<n-1; i++)
            	  if (v[i] > v[i+1]) {
			ok = 0;
			aux=v[i];
			v[i]=v[i+1];
			v[i+1]=aux;
		}
	}
}

int main()
{
	int i, n,v[10001];
	scanf("%d", &n);
	for (i=0; i<n; i++)
		scanf("%d", &v[i]);
	bubbleSort(n,v);
	for (i=0; i<n; i++)
		printf("%d ", v[i]);
	printf("\n");
	return 0;
}
