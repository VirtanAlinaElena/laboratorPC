#include <stdio.h>

int comp(char a[], char b[])
{
	int i=0, ok;
	ok=1; // pp ca a si b sunt egale
	while (ok==1)
	{
		if ( a[i]!=b[i] )
		{
			ok=0;
			if (a[i] < b[i] )
				return -1;
			else return 1;
		}
		i++;
		if (a[i]==0 || b[i]==0) break;
	}
	return 0;
}
int main()
{
	char a[101];
	char b[101];
	scanf("%s", a);
	scanf("%s", b);
	printf ("%d", comp(a,b));
	return 0;
}
