#include <stdio.h>

int vector(int n, int a[], int m, int b[], int c[])
{
	int i,j, k=0, ok;
	for (i=0; i<n; i++)
	{	ok=0; // pp ca a[i] nu se gaseste in b
		for (j=0; j<m && ok==0; j++)
			if ( a[i]==b[j])
			{
				ok=1;
				c[k]=a[i];
				k++;
			}
	}
	return k;
}
int main()
{
	int n,m,a[1001],b[1001],i,c[1001],k;
	scanf("%d", &n);
	for (i=0; i<n; i++)
		scanf("%d", &a[i]);
	scanf("%d", &m);
	for (i=0; i<m; i++)
		scanf("%d", &b[i]);
	printf("\n");
	k=vector(n,a,m,b,c);
	printf ("%d\n", k);
	for (i=0; i<k; i++)
		printf("%d ", c[i]);
}
