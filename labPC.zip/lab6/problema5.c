#include <stdio.h>

void transform (int v[], int n, int x)
{
	int aux,start,stop;
	start=0;
	stop=n-1;
	while (start<stop)
	{
		while (v[start]<x) start++;
		while (v[stop]>=x) stop--;
		if (v[start]>=x && v[stop]<x)
		{
			aux=v[start];
			v[start]=v[stop];
			v[stop]=aux;
		}
	}
}
int main()
{
	int n,x,i,v[1001];
	scanf("%d %d", &n, &x);
	for (i=0; i<n; i++)
		scanf("%d", &v[i]);
	transform (v,n,x);
	for (i=0; i<n; i++)
		printf("%d ", v[i]);
}
