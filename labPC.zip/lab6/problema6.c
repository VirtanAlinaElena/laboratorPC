#include <stdio.h>

void spirala(int a[][100], int m, int n, int v[])
{
	int i,j;
	int dim=0;
	for (i=1; i<=(n/2)+n%2; i++)
	{		
		for (j=i; j<=n-i+1; j++)
			v[++dim] = a[j][i];
		for (j=i+1; j<=m-i+1; j++)
			v[++dim] = a[n-i+1][j];
		for (j=n-i; j>=i; j--) 
			v[++dim] = a[j][m-i+1];
		for (j=m-i; j>=i+1; j--)
			v[++dim] = a[i][j];
	}
}
void afisare(int v[], int dim)
{
	int i;
	for (i=1; i<=dim; i++)
		printf("%d ", v[i]);
}
int main()
{
	int dimensiune, i, j, a[100][100],v[101],m,n;
	scanf("%d %d", &n, &m);
	for (i=1; i<=n; i++)
		for (j=1; j<=m; j++)
			scanf("%d", &a[i][j]);
	spirala(a,m,n,v);
	afisare(v,m*n);
}
