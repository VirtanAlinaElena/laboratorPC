#include <stdio.h>
#include <math.h>

void trig1(float v[], float ungh[])
{
	ungh[0]= acos( ( (v[0]*v[0]+v[1]*v[1]-v[2]*v[2]) / (2*v[0]*v[1]) ) ) * 180/M_PI;
	ungh[1]= acos ( (v[1]*v[1]+v[2]*v[2]-v[0]*v[0]) / (2*v[1]*v[2]) )* 180/M_PI;
	ungh[2] = acos ( (v[0]*v[0]+v[2]*v[2]-v[1]*v[1]) / (2*v[0]*v[2]) ) * 180/M_PI;
}
void trig2(float x, float y, float z, float *u1, float *u2, float *u3)
{
	*u1=acos( (y*y+z*z-x*x)/(2*y*z) ) * 180/M_PI;
	*u2=acos( (z*z+x*x-y*y)/(2*z*x)  ) * 180/M_PI;
	*u3=acos( (x*x+y*y-z*z)/(2*x*y) ) * 180/M_PI;
}

int main()
{
	float x,y,z,u1,u2,u3, v[3],ungh[3],i;
	scanf ("%f %f %f", &x,&y,&z);
	v[0]=x;
	v[1]=y;
	v[2]=z;

	trig2(x,y,z,&u1,&u2,&u3);
	printf ("%.3f ", u1);
	printf ("%.3f ", u2);
	printf ("%.3f\n", u3);

	trig1(v,ungh);
	printf ("%.3f ", ungh[1]);
	printf ("%.3f ", ungh[2]);
	printf ("%.3f\n ", ungh[0]);

	return 0;

}
