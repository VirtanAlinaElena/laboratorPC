#include <stdio.h>

int main()
{
	int i,j,dim=0;
        for (j=i; j<=n-i+1; j++)
                v[++dim] = a[j][i];
        for (j=i+1; j<=m-i+1; j++)
                v[++dim] = a[n-i+1][j];
        for (j=n-i; j>=i; j--)
                v[++dim] = a[j][m-i+1];
        for (j=m-i; j>=i+1; j--)
                v[++dim] = a[i][j];
}
