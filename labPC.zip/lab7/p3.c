#include <stdio.h>
#include <string.h>

char *strdel (char *p, int n)
{
	strcpy (p, p+n);
	return p;
}

char *strins (char *p, char *s)
{
	char aux[20];
	strcpy(aux, p);
	strcpy(p,s);
	strcat(p,aux);
}

int main()
{
	char s1[21],s2[21],s[3001]="ala bala portocala",*p;
	gets(s1);
	gets(s2);

	p = strstr(s,s1);
	while (p != NULL)
	{
		strdel( p, strlen(s1) );
		strins (p, s2);
		p = strstr( p+strlen(s2), s1 );
	}
	puts(s);
	return 0;
}