#include <stdio.h>
#include <cstring.h>

char *next (char *from, char *word)
{
	(*word)=strncpy(from, from+)
}
int main()
{
	char s1[101];
	gets(s1);

}