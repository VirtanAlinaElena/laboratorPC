#include <stdio.h>
#include <string.h>

char *substr(char *src, int n, char *dest)
{
	strncpy(dest, src, n);

}
int main()
{
	char s[101],p[101];
	int x,n;
	scanf ("%s %d %d", s, &x, &n);
	substr(s+x, n, p);
	printf("%s\n", p);
}