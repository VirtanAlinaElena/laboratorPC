#include <stdio.h>
#include <stdlib.h>

typedef MAX = 100 ;
typedef struct 
{
	int n;
	int m;
	int** a;
} MATRICE;

MATRICE* creeaza_MATRICE(int n, int m)
{

}

MATRICE* citeste_MATRICE(MATRICE* ma)
{

}

void scrie_MATRICE(MATRICE* ma, MATRICE* mb)
{

}

MATRICE* aduna_MATRICE(MATRICE* ma, MATRICE* mb)
{

}

MATRICE* inmulteste_MATRICE(MATRICE* ma, MATRICE* mb)
{

}

int main()
{
	MATRICE* ma;
	creeaza_MATRICE(ma);
	citeste_MATRICE(ma);
	scrie_MATRICE(ma);
	aduna_MATRICE(ma);
	inmulteste_MATRICE(ma);
}