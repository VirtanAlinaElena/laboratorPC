#include <stdio.h>

struct multime{
	unsigned char a;
};

void init(struct multime *m)
{
	m->a = 0;
}

void add(struct multime *m, int x)
{
	m->a = m->a | (1<<x);
}

void del(struct multime *m, int x)
{
	m->a = m->a & (~(1<<x));
}

void print(struct multime *m)
{
	int i;
	printf("{");
	for (i=0; i < 7; i++)
		if ( ( m->a & (1<<i) ) != 0 )
			printf("% d ", i);
	printf ("}\n");
}

int contains(struct multime *m, int x)
{
	if ( ( m->a & (1<<x) ) == 0 )
		printf("1\n");
	else printf ("0\n");
}

int main()
{
	struct multime m;
	init(&m);

	add(&m, 3);
	print(&m);

	del(&m, 7);
	contains(&m, 1);


}