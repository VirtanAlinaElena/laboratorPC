#include <stdio.h>

enum examen = {C, S, A} 

typedef struct
{
	char nume[15];
	int ore_curs;
	examen tip_examen;
} MATERIA;

MATERIA* citire_MAT(MATERIA* a)
{
	gets("s", a.nume);
	gets("%d", a.ore_curs);
	gets("%c", a.tip_examen);
}

int main()
{
	MATERIA programa[MAX];
}