#include <stdio.h>
#include <math.h>
double integrala( double (*func) (double x), double a, double b, int n )
{
	int i;
	double S;
	double D = (b - a) / n;
	for (i = 0; i < n; i++)
		S += ( func(a + i * D) + func(a + (i+1) * D) ) * D / 2;
	return S;
}
int main()
{
	double (*functie[2]) (double) = {sin, cos};
	double S,a,b;
	int ord,n;
	scanf("%lf %lf %d %d", &a, &b, &n, &ord);
	S = integrala(functie[ord],a,b,n);
	printf("%lf", S);
}