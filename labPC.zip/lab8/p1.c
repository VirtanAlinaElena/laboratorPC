#include <stdlib.h>
#include <stdio.h>
#include <string.h>

char* my_replace(char *s, char *s1, char *s2)
{
	char tmp[100], v[100], *p, aux[101];

	p=strstr(s, s1);
	printf("%s", p);
	strncpy (tmp, s, strlen(p-s));
	strcpy(v, p+strlen(s1));
	strcat(aux, tmp);
	strcat(aux, s2);
	strcat (aux, v);
	printf ("%s\n", tmp);
	printf("%s\n", v);
	printf("%s", aux);
	return aux;
}

int main()
{
	char s[101], s1[101], s2[101];
	gets(s);
	gets(s1);
	gets(s2);
	my_replace(s,s1,s2);
	printf("%s\n", my_replace(s,s1,s2));
}