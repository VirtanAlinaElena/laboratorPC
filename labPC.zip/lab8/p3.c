#include <stdio.h>
#include <string.h>

int main()
{
	int i,j,n,poz,OK,m;
	scanf("%d", &n);
	int ap[1001];
	char **s, s2[100][19];
	s = malloc( n*sizeof(char **) );
	for (i=0; i<n; i++)
	{
		scanf("%s", s2[i]);
		s[i] = malloc ( (strlen(s2[i])+1)*sizeof(char *) );
		strcpy (s[i], s2[i]);

	}
	
	// metoda 1
	m=0; // numarul de cuvinte distincte 
	for (i=0; i<n; i++)
	{
		scanf ("%s", sir[]);
		OK=0; // pp ca sir nu se gaseste in vectorul v
		poz=0;
		for (j=0; j<m && OK==0; j++)
			if ( strcmp(sir, vp[j]) == 0 ) 
			{
				OK=1;
				poz=j;
			}
		if (OK==1) ap[poz]++;
			else {
					ap[m]=1;
					strcpy ( vp[m], sir );
					m++;
				}
	}
	for (i=0; i<m; i++)
		printf ( "%s %d\n", vp[i], ap[i] );


}