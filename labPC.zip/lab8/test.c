#include <stdio.h>
#include <string.h>

void sir(int v[], int n, int* x, int a[])
{
	int i;
	for (i=0; i<n; i++)
		if (v[i]%2==0)
		{
			a[i]=2*v[i];
			(*x)++;
		}
		else a[i]=v[i];
}
int main()
{
	int n,i,v[100];
	int x=0, a[100];
	scanf("%d", &n);
	for (i=0; i<n; i++)
		scanf("%d", &v[i]);
	//for (i=0; i<n; i++)
	sir(v,n, &x,a);
	printf("%d", x);
	printf("\n");
	for (i=0; i<n; i++)
		printf("%d ", a[i]);
	return 0;

}