#include <stdlib.h>
#include <stdio.h>

int main()
{
	int *v, cap, n, x;
	cap=5; // dimensiunea memorie alocata a vectorului
	n=0; // numar curent elemente in vector
	v=malloc(cap*sizeof(int));
	scanf("%d", &x);
	while ( x!=0 ) {
		if (n==cap) {
			cap=cap*2;
			v=realloc(v,cap*sizeof(int)); //realocare
		}
		v[n++]=x;
		scanf("%d", &x);
	}
	for (int i=0; i<n; i++)
		printf ("%d ", v[i]);
	return 0;
}