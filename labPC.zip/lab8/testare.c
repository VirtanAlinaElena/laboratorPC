#include <stdlib.h>
#include <stdio.h>

int main()	
{
	int *pi;
	pi=(int *)malloc(sizeof(int));
	if(pi==NULL){ 
		printf("*** Memorie insuficienta ***");
		return 1; // revenire din main
	}
	printf("valoare:");
	//citirea variabilei dinamice, de pe heap, de lpi!!!
	scanf("%d",pi);  
	*pi=*pi*2; 
	// dublarea valorii
	printf("val=%d,pi(adresa pe heap)=%p,adr_pi=%p\n", *pi, pi, &pi);
	printf("%d %d %d\n",sizeof(*pi), sizeof(pi), sizeof(&pi));
	return 0;
}