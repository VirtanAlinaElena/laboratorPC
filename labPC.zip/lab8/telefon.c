#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void codificare (char text[], char text_codificat[], int* nr)
{
	int i;
	int nr_caract=0;
	for (i = 0; i < strlen(text); i++) {
		switch ( text[i] ) {
			case 'a':
			{
				if (i!=0)
					if (text_codificat[nr_caract-1] == '2') 
						text_codificat[nr_caract++] = '#';
				text_codificat[nr_caract++] = '2';
				break;
			}
			case 'A':
			{
				text_codificat[nr_caract++] = '1';
				text_codificat[nr_caract++] = '2';
				break;
			}
			case 'b':
			{
				if (i!=0)
					if (text_codificat[nr_caract-1] == '2') 
						text_codificat[nr_caract++] = '#';
				for (i=0; i<1; i++)
					text_codificat[nr_caract++] = '2';
				break;
			}
			case 'B':
			{
				text_codificat[nr_caract++] = '1';
				text_codificat[nr_caract++] = '2';
				text_codificat[nr_caract++] = '2';
				break;
			}
			case 'c':
			{
				if (i!=0)
					if (text_codificat[nr_caract-1] == '2') 
						text_codificat[nr_caract++] = '#';
				for (i=0; i<2; i++) 
					text_codificat[nr_caract++] = '2';
				break;
			}
			case 'C':
			{
				text_codificat[nr_caract++] = '1';
				for (i=0; i<2; i++)
					text_codificat[nr_caract++] = '2';
				break;
			}
			case 'd':
			{
				if (i!=0)
					if (text_codificat[nr_caract-1] == '3') 
						text_codificat[nr_caract++] = '#';
				text_codificat[nr_caract++] = '3';
				break;
			}
			case 'D':
			{
				text_codificat[nr_caract++] = '1';
				text_codificat[nr_caract++] = '3';
				break;
			}
			case 'e':
			{
				if (i!=0)
					if (text_codificat[nr_caract-1] == '3') 
						text_codificat[nr_caract++] = '#';
				text_codificat[nr_caract++] = '3';
				text_codificat[nr_caract++] = '3';
				break;
			}
			case 'E':
			{
				text_codificat[nr_caract++] = '1';
				text_codificat[nr_caract++] = '3';
				text_codificat[nr_caract++] = '3';
				break;
			}
			case 'f':
			{
				if (i!=0)
					if (text_codificat[nr_caract-1] == '3') 
						text_codificat[nr_caract++] = '#';
				text_codificat[nr_caract++] = '3';
				text_codificat[nr_caract++] = '3';
				text_codificat[nr_caract++] = '3';
				break;
			}
			case 'F':
			{
				text_codificat[nr_caract++] = '1';
				text_codificat[nr_caract++] = '3';
				text_codificat[nr_caract++] = '3';
				text_codificat[nr_caract++] = '3';
				break;
			}
			case 'g':
			{
				if (i!=0)
					if (text_codificat[nr_caract-1] == '4') 
						text_codificat[nr_caract++] = '#';
				text_codificat[nr_caract++] = '4';
				break;
			}
			case 'G':
			{
				text_codificat[nr_caract++] = '1';
				text_codificat[nr_caract++] = '4';
				break;
			}
			case 'h':
			{
				if (i!=0)
					if (text_codificat[nr_caract-1] == '4') 
						text_codificat[nr_caract++] = '#';
				text_codificat[nr_caract++] = '4';
				text_codificat[nr_caract++] = '4';
				break;
			}
			case 'H':
			{
				text_codificat[nr_caract++] = '1';
				text_codificat[nr_caract++] = '4';
				text_codificat[nr_caract++] = '4';
				break;
			}
			case 'i':
			{
				if (i!=0)
					if (text_codificat[nr_caract-1] == '4') 
						text_codificat[nr_caract++] = '#';
				text_codificat[nr_caract++] = '4';
				text_codificat[nr_caract++] = '4';
				text_codificat[nr_caract++] = '4';
				break;
			}
			case 'I':
			{
				text_codificat[nr_caract++] = '1';
				text_codificat[nr_caract++] = '4';
				text_codificat[nr_caract++] = '4';
				text_codificat[nr_caract++] = '4';
				break;
			}
			case 'j':
			{
				if (i!=0)
					if (text_codificat[nr_caract-1] == '5') 
						text_codificat[nr_caract++] = '#';
				text_codificat[nr_caract++] = '5';
				break;
			}
			case 'J':
			{
				text_codificat[nr_caract++] = '1';
				text_codificat[nr_caract++] = '5';
				break;
			}
			case 'k':
			{
				if (i!=0)
					if (text_codificat[nr_caract-1] == '5') 
						text_codificat[nr_caract++] = '#';
				text_codificat[nr_caract++] = '5';
				text_codificat[nr_caract++] = '5';
				break;
			}
			case 'K':
			{
				text_codificat[nr_caract++] = '1';
				text_codificat[nr_caract++] = '5';
				text_codificat[nr_caract++] = '5';
				break;
			}
			case 'l':
			{
				if (i!=0)
					if (text_codificat[nr_caract-1] == '5') 
						text_codificat[nr_caract++] = '#';
				text_codificat[nr_caract++] = '5';
				text_codificat[nr_caract++] = '5';
				text_codificat[nr_caract++] = '5';
				break;
			}
			case 'L':
			{
				text_codificat[nr_caract++] = '1';
				text_codificat[nr_caract++] = '5';
				text_codificat[nr_caract++] = '5';
				text_codificat[nr_caract++] = '5';
				break;
			}
			case 'm':
			{
				if (i!=0)
					if (text_codificat[nr_caract-1] == '6') 
						text_codificat[nr_caract++] = '#';
				text_codificat[nr_caract++] = '6';
				break;
			}
			case 'M':
			{
				text_codificat[nr_caract++] = '1';
				text_codificat[nr_caract++] = '6';
				break;
			}
			case 'n':
			{
				if (i!=0)
					if (text_codificat[nr_caract-1] == '6') 
						text_codificat[nr_caract++] = '#';
				text_codificat[nr_caract++] = '6';
				text_codificat[nr_caract++] = '6';
				break;
			}
			case 'N':
			{
				text_codificat[nr_caract++] = '1';
				text_codificat[nr_caract++] = '6';
				text_codificat[nr_caract++] = '6';
				break;
			}
			case 'o':
			{
				if (i!=0)
					if (text_codificat[nr_caract-1] == '6') 
						text_codificat[nr_caract++] = '#';
				text_codificat[nr_caract++] = '6';
				text_codificat[nr_caract++] = '6';
				text_codificat[nr_caract++] = '6';
				break;
			}
			case 'O':
			{
				text_codificat[nr_caract++] = '1';
				text_codificat[nr_caract++] = '6';
				text_codificat[nr_caract++] = '6';
				text_codificat[nr_caract++] = '6';
				break;
			}
			case 'p':
			{
				if (i!=0)
					if (text_codificat[nr_caract-1] == '7') 
						text_codificat[nr_caract++] = '#';
				text_codificat[nr_caract++] = '7';
				break;
			}
			case 'P':
			{
				text_codificat[nr_caract++] = '1';
				text_codificat[nr_caract++] = '7';
				break;
			}
			case 'q':
			{
				if (i!=0)
					if (text_codificat[nr_caract-1] == '7') 
						text_codificat[nr_caract++] = '#';
				text_codificat[nr_caract++] = '7';
				text_codificat[nr_caract++] = '7';
				break;
			}
			case 'Q':
			{
				text_codificat[nr_caract++] = '1';
				text_codificat[nr_caract++] = '7';
				text_codificat[nr_caract++] = '7';
				break;
			}
			case 'r':
			{
				if (i!=0)
					if (text_codificat[nr_caract-1] == '7') 
						text_codificat[nr_caract++] = '#';
				text_codificat[nr_caract++] = '7';
				text_codificat[nr_caract++] = '7';
				text_codificat[nr_caract++] = '7';
				break;
			}
			case 'R':
			{
				text_codificat[nr_caract++] = '1';
				text_codificat[nr_caract++] = '7';
				text_codificat[nr_caract++] = '7';
				text_codificat[nr_caract++] = '7';
				break;
			}
			case 's':
			{
				if (i!=0)
					if (text_codificat[nr_caract-1] == '7') 
						text_codificat[nr_caract++] = '#';
				text_codificat[nr_caract++] = '7';
				text_codificat[nr_caract++] = '7';
				text_codificat[nr_caract++] = '7';
				text_codificat[nr_caract++] = '7';
				break;
			}
			case 'S':
			{
				text_codificat[nr_caract++] = '1';
				text_codificat[nr_caract++] = '7';
				text_codificat[nr_caract++] = '7';
				text_codificat[nr_caract++] = '7';
				text_codificat[nr_caract++] = '7';
				break;
			}
			case 't':
			{
				if (i!=0)
					if (text_codificat[nr_caract-1] == '8') 
						text_codificat[nr_caract++] = '#';
				text_codificat[nr_caract++] = '8';
				break;
			}
			case 'T':
			{
				text_codificat[nr_caract++] = '1';
				text_codificat[nr_caract++] = '8';
				break;
			}
			case 'u':
			{
				if (i!=0)
					if (text_codificat[nr_caract-1] == '8') 
						text_codificat[nr_caract++] = '#';
				text_codificat[nr_caract++] = '8';
				text_codificat[nr_caract++] = '8';
				break;
			}
			case 'U':
			{
				text_codificat[nr_caract++] = '1';
				text_codificat[nr_caract++] = '8';
				text_codificat[nr_caract++] = '8';
				break;
			}
			case 'v':
			{
				if (i!=0)
					if (text_codificat[nr_caract-1] == '8') 
						text_codificat[nr_caract++] = '#';
				text_codificat[nr_caract++] = '8';
				text_codificat[nr_caract++] = '8';
				text_codificat[nr_caract++] = '8';
				break;
			}
			case 'V':
			{
				text_codificat[nr_caract++] = '1';
				text_codificat[nr_caract++] = '8';
				text_codificat[nr_caract++] = '8';
				text_codificat[nr_caract++] = '8';
				break;
			}
			case 'w':
			{
				if (i!=0)
					if (text_codificat[nr_caract-1] == '9') 
						text_codificat[nr_caract++] = '#';
				text_codificat[nr_caract++] = '9';
				break;
			}
			case 'W':
			{
				text_codificat[nr_caract++] = '1';
				text_codificat[nr_caract++] = '9';
				break;
			}
			case 'x':
			{
				if (i!=0)
					if (text_codificat[nr_caract-1] == '9') 
						text_codificat[nr_caract++] = '#';
				text_codificat[nr_caract++] = '9';
				text_codificat[nr_caract++] = '9';
				break;
			}
			case 'X':
			{
				text_codificat[nr_caract++] = '1';
				text_codificat[nr_caract++] = '9';
				text_codificat[nr_caract++] = '9';
				break;
			}
			case 'y':
			{
				if (i!=0)
					if (text_codificat[nr_caract-1] == '9') 
						text_codificat[nr_caract++] = '#';
				text_codificat[nr_caract++] = '9';
				text_codificat[nr_caract++] = '9';
				text_codificat[nr_caract++] = '9';
				break;
			}
			case 'Y':
			{
				text_codificat[nr_caract++] = '1';
				text_codificat[nr_caract++] = '9';
				text_codificat[nr_caract++] = '9';
				text_codificat[nr_caract++] = '9';
				break;
			}
			case 'z':
			{
				if (i!=0)
					if (text_codificat[nr_caract-1] == '9') 
						text_codificat[nr_caract++] = '#';
				text_codificat[nr_caract++] = '9';
				text_codificat[nr_caract++] = '9';
				text_codificat[nr_caract++] = '9';
				text_codificat[nr_caract++] = '9';
				break;
			}
			case 'Z':
			{
				text_codificat[nr_caract++] = '1';
				for (i=0; i<2; i++)
					text_codificat[nr_caract++] = '9';
				break;
			}
			case ' ':
			{
				text_codificat[nr_caract++] = '0';
				break;
			}
		}
	}
	*nr=nr_caract;
}

void decodificare (char sir[], char text_decodif[], int* nr2)
{
	int i, lung_secv = 0, nr_caract = 0;
	if (sir[0] == 1)
		lung_secv = 0;
	else lung_secv = 1;

	for (i = 1; i < strlen(sir); i++)
	{
		if (sir[i-1] == '1' || sir[i] == sir[i-1] || sir[i-1] == '#') 
			lung_secv++;
		else
		{
			if (s[i] == '1' || s[i] == '#') lung_secv = 0;
				else lung_secv = 1;
			switch (sir[i-1])
			{
				case '2':
				{
					if (lung_secv == 1) 
						text_decodif[nr_caract++]='a';
					if (lung_secv == 2) 
						text_decodif[nr_caract++]='b';
					if (lung_secv == 3) 
						text_decodif[nr_caract++]='c';
					break;
				}
				case '3':
				{
					if (lung_secv == 1) 
						text_decodif[nr_caract++]='d';
					if (lung_secv == 2) 
						text_decodif[nr_caract++]='e';
					if (lung_secv == 3) 
						text_decodif[nr_caract++]='f';
					break;
				}
				case '4':
				{
					if (lung_secv == 1) 
						text_decodif[nr_caract++]='g';
					if (lung_secv == 2) 
						text_decodif[nr_caract++]='h';
					if (lung_secv == 3) 
						text_decodif[nr_caract++]='i';
					break;
				}
				case '5':
				{
					if (lung_secv == 1) 
						text_decodif[nr_caract++]='j';
					if (lung_secv == 2) 
						text_decodif[nr_caract++]='k';
					if (lung_secv == 3) 
						text_decodif[nr_caract++]='l';
					break;
				}
				case '6':
				{
					if (lung_secv == 1) 
						text_decodif[nr_caract++]='m';
					if (lung_secv == 2) 
						text_decodif[nr_caract++]='n';
					if (lung_secv == 3) 
						text_decodif[nr_caract++]='o';
					break;
				}
				case '7':
				{
					if (lung_secv == 1) 
						text_decodif[nr_caract++]='p';
					if (lung_secv == 2) 
						text_decodif[nr_caract++]='q';
					if (lung_secv == 3) 
						text_decodif[nr_caract++]='r';
					if (lung_secv == 4)
						text_decodif[nr_caract++]='s';
					break;
				}
				case '8':
				{
					if (lung_secv == 1) 
						text_decodif[nr_caract++]='t';
					if (lung_secv == 2) 
						text_decodif[nr_caract++]='u';
					if (lung_secv == 3) 
						text_decodif[nr_caract++]='v';
					break;
				}
				case '9':
				{
					if (lung_secv == 1) 
						text_decodif[nr_caract++]='w';
					if (lung_secv == 2) 
						text_decodif[nr_caract++]='x';
					if (lung_secv == 3) 
						text_decodif[nr_caract++]='y';
					if (lung_secv == 4)
						text_decodif[nr_caract++]='z';
					break;
				}
			}
			if (sir[i] == '1' || sir[i] == '#') 
				lung_secv = 0;
			else
				lung_secv = 1;		
		}
	}
int main()
{
	int i;
	//Cerinta 1
	char text[100], text_codificat[300];
	int nr=0; //numarul de caractere al textului codificat
	gets(text);
	codificare(text, text_codificat, &nr);
	for (i = 0; i < nr; i++)
		printf("%c", text_codificat[i]);
	printf("\n");

	//Cerinta 2
	char sir[300], text_decodif[100];
	int nr2=0; //numarul de caractere al textului decodificat
	gets(sir);
	decodificare(sir, text_decodif, &nr2);
	for (i = 0; i < nr2; i++)
		printf("%c", text_decodif[i]);
	printf("\n");

	return 0;
}