#include <stdio.h>

int main ()
{
	int n,k,s,i,x;
	scanf("%d", &n);
	s=0;
	for (i=1; i<=n; i++)
	{
		x=i;
		k=0; // nr de cifre ale unui nr
		while (x!=0)
		{
			x/=10;
			k++;
		}
		s=s+k;
	}
	printf("%d\n", s);
}