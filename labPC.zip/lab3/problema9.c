#include <stdio.h>

int main()
{
	int n,a,b,c,k,OK,d;
	scanf("%d", &n);
	a=0;
	b=1;
	k=2; //nr de termeni generati
	while (k<n)
	{
		c=a+b;
		a=b;
		b=c;
		k++;
		OK=1;
		if (c<=1) OK=0;
		d=2;
		while (d*d<=c && OK==1)
			if (c%d==0) OK=0;
				else d++;
		if (OK==1) printf("%d\n", c);
	}
	return 0;
}