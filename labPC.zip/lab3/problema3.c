#include <stdio.h>

int main()
{
	int a,b,s,x; 
	scanf("%d%d", &a,  &b);
	while (b!=0)
	{
		x=a;
		s=0;
		while(x!=0)
		{
			s=s+x%10;
			x/=10;
		}
		if (a%s==b) printf("(%d, %d)\n", a, b);
		a=b;
		scanf("%d", &b);
	}
	if (b==0)
	{
		x=a;
		s=0;
		while(x!=0)
		{
			s=s+x%10;
			x/=10;
		}
		if(a%s==b) printf("(%d, %d)\n", a, b);
	}
	return 0;
}