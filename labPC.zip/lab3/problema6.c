#include <stdio.h>

int main()
{
	/*int n,k,fact1=1,fact2=1,fact3=1,i, C;
	scanf("%d%d", &n, &k);
	for (i=1; i<=n; i++)
		fact1*=i;
	for (i=1; i<=k; i++)
		fact2*=i;
	for (i=1; i<=n-k; i++)
		fact3*=i;
	C=fact1/(fact2*fact3);
	printf( "%d\n", C ); */
	int c=1,m,n,k;
	scanf("%d%d", &n, &m);
	for (k=1; k<=m; k++)
	{
		c*=(n-k+1)/k;
	}
	printf("%d/n", c);
	return 0;
}