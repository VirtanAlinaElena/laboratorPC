#include <stdio.h>

int main()
{
	int i;
	char ch=' ';
	for (i=1; i<=96; i++)
	{
		printf("%c = %d ", ch, ch);
		ch++;
		if (i%10==0) printf("\n");
	}
	return 0;
}