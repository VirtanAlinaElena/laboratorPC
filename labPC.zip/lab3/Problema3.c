#include <stdlib.h>
#include <stdio.h>

int main()
{
	int n;
	float x;
	double y;
	scanf("%d %f %lf", &n, &x, &y);
	float sx = 0;
	double sy = 0;
	for(int i = 0; i <= n; i += n/10)
	{
		if(i != 0) printf("%f %e %f %e\n", sx, sx, sy, sy);
		for(int j = 1; j <= n/10; ++j)
		{
			sx += x;
			sy += y;
		}
	}
	return 0;
}