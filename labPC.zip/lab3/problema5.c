#include <stdio.h>

int main()
{
	int P,i,j;
	scanf("%d", &P);
	if (P==0) printf("0 0 0\n");
	for (i=0; i<=P/2; i++)
		for (j=0; j<=P/2; j++)
			if (i<=j+(P-i-j) && j<=i+(P-i-j) && P-i-j<=i+j && i<=j && j<=P-i-j)
				printf ("%d %d %d\n", i, j, P-i-j);
}